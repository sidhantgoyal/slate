//
//  WMTSDKKit.h
//  WMTSDKKit
//
//  Created by Siddhant Goyal on 12/30/15.
//  Copyright © 2015 Walmart. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WMTSDKKit.
FOUNDATION_EXPORT double WMTSDKKitVersionNumber;

//! Project version string for WMTSDKKit.
FOUNDATION_EXPORT const unsigned char WMTSDKKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WMTSDKKit/PublicHeader.h>


